#!/usr/bin/env bash

sudo apt-get update -y && sudo apt-get upgrade -y