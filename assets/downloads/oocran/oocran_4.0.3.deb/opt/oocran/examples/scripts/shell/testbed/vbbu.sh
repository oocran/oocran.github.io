sudo apt-get install git -y
git clone https://github.com/oocran/vbbu.git
cd vbbu
chmod 777 install
./install